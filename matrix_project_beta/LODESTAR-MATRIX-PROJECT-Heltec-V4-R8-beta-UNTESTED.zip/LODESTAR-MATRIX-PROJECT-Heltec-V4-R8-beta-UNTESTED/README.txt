LODESTAR MATRIX PROJECT  -  BETA 1
PROJECT MATRIX. By: Aries Thorne. For: Matrix Comm. Systems.
==========================================================================

*** READ THIS FIRST: THIS ZIP IS FOR THE HELTEC V4 R8, AND IT IS UNTESTED ***
The firmware in this zip was built for the Heltec V4 R8, and the build finished
without errors, but nobody has been able to run it on that radio yet. The
steps and the dashboard are the same as in the manual (which is written for
the Heltec V4 R2). Use this zip ONLY if you own a Heltec V4 R8, and be ready for
surprises. Do not flash it onto any other radio.

PROJECT MATRIX is companion firmware for a MeshCore radio, with a
Matrix-style dashboard that runs in your web browser. Falling green code,
a radar, a deck of live information tiles, a command line, and a menu to
Block, Decode or Hack (look up) the radios you hear.

THIS IS A BETA. It has not been tested on a real radio by its makers. The
firmware builds correctly and the dashboard was tested with sample data in
a browser. A mesh radio is a backup, not a replacement for a phone or 911.

WHAT IS IN THIS ZIP
  README.txt                                   this file
  QUICK-START-GUIDE.pdf                        two pages, steps only
  LODESTAR-MATRIX-PROJECT-Users-Manual.pdf     the full manual (start here
                                               if you are new to all this)
  matrix.html                                  the dashboard: double-click
  US\firmware-merged.bin                       US edition, full install
  US\firmware-update.bin                       US edition, update (keeps settings)
  UK-EU\firmware-merged.bin                    UK/EU edition, full install
  UK-EU\firmware-update.bin                    UK/EU edition, update

US or UK-EU? Only the speed unit differs (US: miles per hour, UK-EU:
kilometres per hour). Use ONE folder. The radio region (frequency) is a
separate setting you choose in the MeshCore app.

QUICK START
  1. Screw the antenna on BEFORE powering the radio. Never power a radio
     without its antenna.
  2. Plug the radio into the computer with a USB DATA cable.
  3. In Chrome or Edge open https://flasher.meshcore.io, choose
     "Custom Firmware", pick firmware-merged.bin from your folder (US or
     UK-EU), Connect, Flash. Leave "Erase" OFF.
  4. Unplug and replug the radio. The screen shows PROJECT MATRIX.
  5. Pair the radio with the free MeshCore app (PIN on the radio's screen)
     and choose the USA/Canada or EU/UK region preset.
  6. Double-click matrix.html, enter an alias, click "Try sample data" to
     look around, or "Connect radio" to use your own.

Already running NOVA, ORION, OTR or MATRIX? Flash firmware-update.bin
instead, with Erase OFF, to keep your settings.

More help is in the manual. Report problems at
https://github.com/propertymonitor-web/lodestar-beta-releases

Engineered by: Aries Thorne & Todd Steinhauer for Wolf Reactive Systems (WRS)
Special thanks to the NTXMESH community, Meshcore Community, and Pat Steinhauer-Scates for their guidance and support.

Happy Meshing
from Aries Thorne & Todd Steinhauer of Wolf Reactive Systems
