LODESTAR ORION  -  wardriving edition  -  BETA 1
by FEAR REACTIVE
==========================================================================

ORION maps the MeshCore radios around you. Drive or walk with it and it
records every REPEATER and COMPANION it hears, and where. On your computer
it draws your route on a real street map, with a green dot for every
repeater and a blue square for every companion, and lets you download the
list with locations.

ORION is the LODESTAR NOVA companion firmware with the ORION name. You pair
it with the MeshCore phone app as normal. It also keeps NOVA's message
delivery tracking and link health.

This is a BETA test build, for the Heltec WiFi LoRa 32 V4 R2 (the radio
WITH the small screen; not the V4-R8). It has not been run on every kind
of radio yet, so please report anything odd.


WHAT IS IN THIS ZIP
  readme.txt                      this file
  LODESTAR-ORION-dashboard.html   the dashboard: double-click it
  US\firmware-merged.bin          US edition (speed in miles per hour)
  US\firmware.bin                 same, for updating a radio that already
                                  runs NOVA or ORION and keeping its settings
  EU\firmware-merged.bin          EU edition (speed in km/h)
  EU\firmware.bin                 same, for updating

Use ONE folder: US or EU. The only difference is the speed unit.
(Distances are always metres and kilometres.)
The radio region (frequency) is a separate setting, see step 3.


WHAT YOU NEED
  * A Heltec V4 R2 with its antenna attached.
  * A GPS for the Heltec, such as a GNSS module in its GPS connector.
    WITHOUT A GPS, ORION can still list the nodes it hears, but it can only
    put them on the map if they announce their own position.
  * The free MeshCore app on your phone.
  * A computer with Google Chrome or Microsoft Edge, and a USB DATA cable.


STEP 1 - FLASH ORION
  1. Screw the antenna on BEFORE powering the radio.
  2. Plug the radio into the computer with the USB data cable.
  3. In Chrome or Edge open  https://flasher.meshcore.io
  4. Choose "Custom Firmware" and pick  firmware-merged.bin  from the US or
     EU folder. Click Connect, pick the radio's port, click Flash.
  5. When it is done, unplug and replug the radio. The screen shows
     LODESTAR / ORION.
  If the radio is not listed: hold PRG, tap RST, let go of PRG, try again.
  Leave any "Erase" option OFF unless you want a completely fresh start
  (erasing deletes your contacts and settings).

  ALREADY RUNNING NOVA OR ORION? Flash  firmware.bin  instead, as an update,
  with Erase OFF. Your settings, contacts and channels are kept.


STEP 2 - PAIR YOUR PHONE
  1. Turn Bluetooth on. In the MeshCore app add / connect a device and pick
     your radio.
  2. The pairing PIN is shown on the radio's screen: press its button
     briefly to step through the screens until you see the Bluetooth screen.


STEP 3 - SET THE RADIO REGION
  In the MeshCore app open the radio settings and pick the preset for where
  you are ("USA/Canada" or "EU/UK"), or the settings your local MeshCore
  community uses. Save. The radio restarts.
  You can only hear the radios that use the same settings as you, so the
  region matters: a wrong one means an empty map. Transmit only the way
  your local radio rules allow.


STEP 4 - TURN ON GPS
  In the MeshCore app (or on the radio's GPS screen) switch GPS on.
  ORION never turns it on by itself. Give it a few minutes with a view of
  the sky for its first fix. The dashboard shows "satellites" once it has one.


STEP 5 - OPEN THE DASHBOARD AND GO
  1. Double-click  LODESTAR-ORION-dashboard.html  (it opens in your browser;
     use Chrome or Edge).
  2. Click "Connect radio" and choose the radio's port (close the flasher
     page first, only one program can use the port). Keep the radio plugged
     into the computer. Your phone can stay connected by Bluetooth.
  3. Within a few seconds the readouts fill in and the title changes to
     "LODESTAR ORION wardriving dashboard".
  4. Drive or walk. Your route is drawn in purple. Repeaters appear as
     green dots and companions as blue squares. A faded marker means that
     node did not announce its position, so it is shown where you heard it.
     Click any marker for its name, signal and when it was heard.
  5. "Follow me" keeps the map on you. Drag the map to look around, press
     "Show everything" to zoom out to the whole trip.

  ABOUT THE MAP: the street map is built from OpenStreetMap data, with map
  pictures from CARTO (the default) or from OpenStreetMap itself (pick it
  in the "Map" list above the map). Online, it needs internet. If one
  source fails, the dashboard tries the other by itself, or you can pick it
  in the Map list.

  MAPS FOR NO SIGNAL (OFFLINE MAPS): do this at home, before the trip.
  Find the "Offline maps" box on the dashboard. The list has all 50 US
  states and a special "Route 66 (Chicago to Santa Monica)" map. Pick one,
  press Download, then use "Load a map file" and choose the file you just
  downloaded. Files are 7 to 380 MB, so use Wi-Fi. You can load several. It is kept in this browser and appears in the Map list as
  "Offline: <region>". With no internet the dashboard switches to it. The
  map is blank outside the region you downloaded, so pick one that covers
  the whole trip. Use the same browser each time (a copy of the dashboard
  opened from a file keeps its maps separately from the online page).

  The route and the list are still recorded when the map is blank or you
  are offline (for example in the car with no signal), and they draw on
  the map once it can load. They are kept in your browser, so a refresh or
  closing the tab does not lose them. Use the SAME copy (the file or the
  web address) for the whole trip, because each keeps its own memory.
  The map sources are free for light personal use and ask for the credit
  shown on the map. For heavy or commercial use you need your own map
  provider.


STEP 6 - DOWNLOAD YOUR LOG
  In the "Nodes found" panel:
    Download list (CSV)               opens in Excel or Google Sheets
    Download map file (GeoJSON)       for mapping programs
    Download route + nodes (GPX)      for GPS and map apps
  "Clear found list" empties the list (on the page and on the radio).
  "Clear trip and route" in Settings starts a fresh route.
  The CSV has, for every node: type, name, key, the position it announced,
  the position YOU were at when you heard it best, signal, number of hops,
  how many times it was heard, and when.


GOOD TO KNOW
  * The radio remembers the 48 most recent nodes. The dashboard keeps up to
    5000. Keep the dashboard connected while you drive so nothing is missed.
  * "Hops" tells you whether you heard a node directly (0) or through
    repeaters. For a node you heard through repeaters, the position you
    heard it at is where YOU were, not where the sender is.
  * Room servers and sensors appear in the downloads but are not drawn.
  * The radio's screen does not show the found list: the dashboard does.
  * For a longer drive, power the radio from a USB battery or car charger.

PLEASE KEEP YOUR LOGS PRIVATE
  The files contain other people's radio names and the places they
  announced. A companion is usually a person. ORION only listens to the
  adverts that radios broadcast openly, but please do not publish a list of
  names and positions of private individuals.

IF SOMETHING GOES WRONG
  * Flasher cannot see the radio: another USB cable or port, or bootloader
    mode (hold PRG, tap RST, release PRG).
  * Dashboard says "waiting for data" or stays empty: you need the
    Bluetooth firmware (this one is), a USB data cable, and no other
    program using the port.
  * No nodes appear: check the region (step 3) and the antenna, and give it
    a few minutes. Adverts are only sent every so often.
  * Nodes appear but not on the map: the radio has no GPS fix (step 4) and
    those nodes do not announce a position.
  * Speed shows "undefined" or the wrong unit: re-flash this firmware.
  * Blank map or "tile usage policy" pictures: see "ABOUT THE MAP" above.
  * Blank map with no signal: load an offline map for the area first (see
    "MAPS FOR NO SIGNAL"). The map is blank outside the area you loaded.
  * The region list says "List not available": it needs internet. Connect
    once, reload the dashboard, and the list appears.

Updates: https://github.com/propertymonitor-web/lodestar_nova_alpha/releases
Bug reports: https://github.com/propertymonitor-web/lodestar_nova_alpha/issues

A radio network is a backup, not a replacement for 911 or good preparation.
